from alipay import AliPay

'''
请前往 开放平台 https://openhome.alipay.com/ 注册自研服务应用 ｜ 注意：不要注册第三方应用，权限不足
路径：我的应用>自研服务>网页&移动应用
1、添加当面付能力
2、接口加签方式：公钥>填写自己生成的应用公钥 (RSA2)
3、配置下面的信息，大功告成！
'''

# 配置区域

# appid
appid="2021001151689823"

# 应用私钥
app_private_key_string = "-----BEGIN RSA PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCijrAKJX3E5KfwIjdwdVH97XV7NK/sNR5FKnDZqzWGDY1SVU0rmzV1B2PbTXuj5JPYHAczXqnfh1B7TDQIEkLKIXdBaduBnI8YbNYuMZnuDkMObaDKGz7940iDXC51QpR/L9fo14jW7WdYNWzdFgHf0Ek3Q+n8TDV1ZdRZm1RL6BW3nEBq3Zwl3nJgjQ1ij4F/e+y/IE7ZXBVyfDXXA37onu82AzUvGd8k3DVDAoz/9sGGHxILo+fphq0TT2AddGcK9Suy0F0PX/5SCd3PPqO8aIEG25+d2JkyMWz9JmeKAup+Fgt7v/0+ZJw1kowi9rXBvZ00bUbX+uauQJrdZqFfAgMBAAECggEAMn0E2jHozTWDn4bRF0GpFKgjHAAyP7gDzdGvuTt+5ULiSNcrn8aWJOIFtsBrDW1aKf4SknbtZfq+GX2Cj5s0WVlpk8yQG8KHgzuSjkhjmdeeJiYQkZVCzFJCXGJOH6dtPc+bTLtcyfx0Y6Y8SLKkJGKpyttyGiWFWRAmkyo2VVihSY2C1PztahYJB7zxtZtz5FTwGr3XIHFiGTOF4iYgYAAek+5dQDYR+1Bv+NrMXaLVt9+HHOiEdcuk3Gk/ayWw2JhD533AXJBTIu7RZgVPuzXA8A94HBp0iLdnCMTIkBAreZ4jBMvZJBj3wO8JzcwkqiUT8+3Cgc2/jr7gvLuiQQKBgQDo2jPPWh13UfKJgqYeO5UHGJItapbgdMfjeVRlBbiF9Z3y6e1eLCTgGchNWpyEgzvgm5euqCQEkhIlIH4ny0qZRikQO1QlQABajZXlPAZmqL3acjCjpHARoO3hm6L60zM2IKX+q0O/mTkr+vLV/KSgSk25s7SeUOuOYW0DSxhQ/wKBgQCyt5EpDqQEZGXQkkQIyhJkkkrfSrPXexKCaCmtDalENPznRKpumseXeztn6RFp9tkLt/EoszQB//UVHAE6RyhBxfC8tDKVOe2I1lmub+UsFD0xexgfjy2JWebYIn5W6G4W6073FSS+u9gehN37fMlbJpjMtrEbVXD/unPjsONPoQKBgQDfr4Xn4ky+LCXO/YfxMRGXsH30TRnFY8oF9q8hIN7DKVFjYl9ZgRSnh30I+kuzbJJf0XhkGzgGgAAYVF98gOkX1vNpmWTbJ+FvG+ZsQT5w7hb7u4iIG1ZhSPRcL3PgenUOwUxVGldJvrrSSg9vi3TmWprSExUmpNu0elkLud8RJwKBgG8zPQU48OEyvw86E08MvMkLJb8uMhyfnXK68UOWPn4MIlicJxfPAuXEbcBICufOClr6Rvm2F2QvKQXLeRAT+n6CdTpVPSwQ8TW1efPJ9+SnazQAjZAFfKX75GEThVz6HpXwMCAZbdWn9991eNHkYT1wFJ88BZMmZLsZ/sXr6GRBAoGASOttFxhWh1L7SCv37hr1LQ4sQQ3hkwID4TJ6RqbZVD4oxGsZD5P5OqE3+fFfr97fnFu1eYu6vVgLn9kBzcroa4jWJbZxv74dv7asEhynawiGkhq9NTZ+2VNBdhecNoaSjwYRwQeWbwESaeZrlwCYRsZqt/U+EaXnr81+pjqXZ9o=\n-----END RSA PRIVATE KEY-----"

# 支付宝公钥，验证支付宝回传消息使用，不是你自己的公钥,
alipay_public_key_string = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjidQFFpINgtdAMzBWFVUulQ0UbjjEVxpPJQ3VZo276wUhjDsum80ncPh49gUKT3BLJ3bFEDFT7hMnmtjViWeS3B8CYEoHEloAz0Gepy2mSbFZWBRCayFcntl5kTji1xzrqAUxkUzWDfOU3vgI9Y+2n25FIdHb6R508Dka53GeFUaWQklVaWjHPnnT8AnSwMaKNBa1Mj1SEtlvC9VogMafnjDhdnUVKznOVVrqXWUJlw6o9WiEXtUSEtu1l2vnRyx6yimHT6LCC3bMiZp5efbvYoNOojvhl61tAsej+IF4D1eG48Yke0+mFh7rt5O3GBmPqVSrLMtyopQclp93zDtHwIDAQAB\n-----END PUBLIC KEY-----"

# 示例格式 注意\n
# alipay_public_key_string = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAw9QbJi++cm2HjinPpllj3Hmep8nxO9MVu0BTSP1XM1wF666g6sTwQ0VXyRJENpYEs0KFE/XnMKilV/+uQY7xH4SqcdX2T4C5DkiWJ4egD2Tk3yLH6fjq7TqCsMqG3osfk6U93H+XdiWKKff+nwQ6LnUIEYWoMIh/fyqTYtlKzBTUg8nJWoqfkspFWlt69PrbosbAFWY7vp+3CapO/o4Qw+thuhGKAvEZWmNy3hUnnThStos+T8qI/Qqs5f9zb9wIDAQAB\n-----END PUBLIC KEY-----"

# 订单超时时间
# m：分钟，只可为整数，建议与config配置的超时时间一致
PAY_TIMEOUT = '5m'

try:
    alipay = AliPay(
        appid=appid,
        app_notify_url=None,  # 默认回调url，不要改
        app_private_key_string=app_private_key_string,
        alipay_public_key_string=alipay_public_key_string,
        sign_type="RSA2",
    )
except Exception as e:
    print(e)
    print('Alipay对象创建失败，请检查公钥和密钥是否配置正确')


def submit(price, subject, trade_id):
    try:
        order_string = alipay.api_alipay_trade_precreate(
            subject=subject,
            out_trade_no=trade_id,
            total_amount=price,
            qr_code_timeout_express=PAY_TIMEOUT
        )
        print(order_string)
        if order_string['msg'] == 'Success':
            pr_code = order_string['qr_code']
            print(pr_code)
            return_data = {
                'status': 'Success',
                'type': 'qr_code',  # url / qr_code
                'data': pr_code
            }
            return return_data
        else:
            print(order_string['msg'])
            return_data = {
                'status': 'Failed',
                'data': 'API请求失败'
            }
            return return_data
    except Exception as e:
        print(e)
        print('支付宝当面付API请求失败')
        return_data = {
            'status': 'Failed',
            'data': 'API请求失败'
        }
        return return_data


def query(out_trade_no):
    try:
        result = alipay.api_alipay_trade_query(out_trade_no=out_trade_no)
        if result.get("trade_status", "") == "TRADE_SUCCESS":
            print(str(result))
            print('支付宝当面付｜用户支付成功')
            return '支付成功'
        else:
            print(str(result))
            print('支付宝当面付｜用户支付失败')
            return '支付失败'
    except Exception as e:
        print(e)
        print(str(result))
        print('支付宝当面付｜请求失败')
        return 'API请求失败'


def cancel(out_trade_no):
    try:
        alipay.api_alipay_trade_cancel(out_trade_no=out_trade_no)
    except Exception as e:
        print(e)