
# 支付超时时间(秒)
PAY_TIMEOUT = 300
# BOT API
TOKEN = '1323181948:AAGFbg4obxYuD_3QC-NhKcCcUzqvgYmn7Ds'
# ADMIN ID
ADMIN_ID = [650099718]

# 管理员命令
ADMIN_COMMAND_START = 'adm'
ADMIN_COMMAND_QUIT = 'exit'

# 支持的支付方式
PAYMENT_METHOD = {
    'alifacepay': '支付宝当面',
    'mugglepay': '加密货币（麻瓜pay）',
}

# 当前版本
VERSION = '1.3.1'